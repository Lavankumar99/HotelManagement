package com.hotelbookingapp.dto;

import java.time.LocalDate;
import java.util.List;

import lombok.Data;

@Data
public class BookingDTO {

	private Integer bookingId;
	private List<CustomerDTO> customer;
	private HotelDTO hotel;
	private LocalDate checkIn;
	private LocalDate checkOut;
	private Integer noOfCustomers;
	private Double totalAmount;
	private RoomDTO room;
	private Long noOfDays;

}
