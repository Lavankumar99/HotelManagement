package com.hotelbookingapp.service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hotelbookingapp.dto.BookingDTO;
import com.hotelbookingapp.dto.CustomerDTO;
import com.hotelbookingapp.dto.HotelDTO;
import com.hotelbookingapp.dto.RoomDTO;
import com.hotelbookingapp.entity.Booking;
import com.hotelbookingapp.entity.Customer;
import com.hotelbookingapp.entity.Hotel;
import com.hotelbookingapp.entity.Room;
import com.hotelbookingapp.entity.User;
import com.hotelbookingapp.exception.BookingNotFoundException;
import com.hotelbookingapp.repository.IBookingRepo;
import com.hotelbookingapp.repository.ICustomerRepo;
import com.hotelbookingapp.repository.IHotelRepo;
import com.hotelbookingapp.repository.IRoomRepo;
import com.hotelbookingapp.repository.IUserRepo;
import com.hotelbookingapp.util.RoomStatus;

@Service
public class BookingServiceImpl implements IBookingService {

	@Autowired
	IRoomRepo roomRepo;
	@Autowired
	IHotelRepo hotelRepo;
	@Autowired
	ICustomerRepo customerRepo;
	@Autowired
	IUserRepo userRepo;

	@Autowired
	IBookingRepo bookingRepo;
	@Autowired
	private ModelMapper modelMapper;

	public String addBookingDetails(LocalDate checkIn, LocalDate checkOut, Integer userId, Integer roomId) {
		Room room = roomRepo.findById(roomId).get();
		User user = userRepo.findById(userId).get();
		List<Customer> customers = customerRepo.findByuserId(userId);

		Integer hotelId = room.getHotel().getHotelId();
		Hotel hotel = hotelRepo.findById(hotelId).get();

		if (customers.size() <= room.getRoomCapacity()) {
			Booking booking = new Booking();
			booking.setCheckIn(checkIn);
			booking.setCheckOut(checkOut);
			booking.setHotel(hotel);
			booking.setCustomerList(customers);
			booking.setNoOfCustomers(customers.size());
			booking.setRoom(room);
			Long noofDays = (Long) ChronoUnit.DAYS.between(checkIn, checkOut);
			booking.setNoOfDays(noofDays);
			booking.setTotalAmount(room.getRatePerDay() * booking.getNoOfCustomers() * noofDays);

			booking.setUser(user);
			room.setStatus(RoomStatus.BOOKED);
			roomRepo.save(room);
			bookingRepo.save(booking);

			return "Booked Successfully";
		} else
			return "Sorry room not Booked! Because the capacity of that room is less than customers ... So please find Another Room .....";
	}

	public String cancelBooking(Integer bookingId) {
		try {

			Booking booking = bookingRepo.findById(bookingId).orElseThrow(() -> new BookingNotFoundException());
			Room room = roomRepo.findById(booking.getRoom().getRoomId()).get();
			bookingRepo.deleteBookedCustomers(bookingId);
			room.setStatus(RoomStatus.AVAILABLE);
			roomRepo.save(room);
			bookingRepo.cancelBooking(bookingId);

		} catch (BookingNotFoundException e) {
			System.out.println(e);
			return "Customer data not updated";

		}
		return "Booking Canceled Successfully";
	}

	public List<BookingDTO> findAllBookings() {
		List<BookingDTO> bookingDTOs = new ArrayList<BookingDTO>();
		List<Booking> bookings = bookingRepo.findAll();

		for (Booking booking : bookings) {
			BookingDTO bookingDTO = new BookingDTO();
			bookingDTO.setBookingId(booking.getBookingId());
			bookingDTO.setCheckIn(booking.getCheckIn());
			bookingDTO.setCheckOut(booking.getCheckOut());
			bookingDTO.setCustomer(MapCustomerToDTO(booking.getCustomerList()));
			bookingDTO.setRoom(MapRoomToDTO(booking.getRoom()));
			bookingDTO.setHotel(mapHotelToDTO(booking.getHotel()));
			bookingDTO.setTotalAmount(booking.getTotalAmount());
			bookingDTO.setNoOfCustomers(booking.getNoOfCustomers());
			bookingDTO.setNoOfDays(booking.getNoOfDays());

			bookingDTOs.add(bookingDTO);
		}
		return bookingDTOs;
	}

	public BookingDTO findByBookingId(Integer bookingId) {
		Booking booking = bookingRepo.findById(bookingId).get();
		BookingDTO bookingDTO = new BookingDTO();
		bookingDTO.setBookingId(booking.getBookingId());
		bookingDTO.setCheckIn(booking.getCheckIn());
		bookingDTO.setCheckOut(booking.getCheckOut());
		bookingDTO.setCustomer(MapCustomerToDTO(booking.getCustomerList()));
		bookingDTO.setRoom(MapRoomToDTO(booking.getRoom()));
		bookingDTO.setHotel(mapHotelToDTO(booking.getHotel()));
		bookingDTO.setTotalAmount(booking.getTotalAmount());
		bookingDTO.setNoOfCustomers(booking.getNoOfCustomers());
		bookingDTO.setNoOfDays(booking.getNoOfDays());

		return bookingDTO;

	}

	public List<BookingDTO> findByUserId(Integer userId) {

		List<Booking> bookings = bookingRepo.findByUserId(userId);
		List<BookingDTO> bookingDTOs = new ArrayList<BookingDTO>();

		for (Booking booking : bookings) {
			BookingDTO bookingDTO = new BookingDTO();
			bookingDTO.setBookingId(booking.getBookingId());
			bookingDTO.setCheckIn(booking.getCheckIn());
			bookingDTO.setCheckOut(booking.getCheckOut());
			bookingDTO.setCustomer(MapCustomerToDTO(booking.getCustomerList()));
			bookingDTO.setRoom(MapRoomToDTO(booking.getRoom()));
			bookingDTO.setHotel(mapHotelToDTO(booking.getHotel()));
			bookingDTO.setTotalAmount(booking.getTotalAmount());
			bookingDTO.setNoOfCustomers(booking.getNoOfCustomers());
			bookingDTO.setNoOfDays(booking.getNoOfDays());

			bookingDTOs.add(bookingDTO);
		}
		return bookingDTOs;
	}

	public List<BookingDTO> findByHotelId(Integer hotelId) {
		List<Booking> bookings = bookingRepo.findByHotelId(hotelId);
		List<BookingDTO> bookingDTOs = new ArrayList<BookingDTO>();

		for (Booking booking : bookings) {
			BookingDTO bookingDTO = new BookingDTO();
			bookingDTO.setBookingId(booking.getBookingId());
			bookingDTO.setCheckIn(booking.getCheckIn());
			bookingDTO.setCheckOut(booking.getCheckOut());
			bookingDTO.setCustomer(MapCustomerToDTO(booking.getCustomerList()));
			bookingDTO.setRoom(MapRoomToDTO(booking.getRoom()));
			bookingDTO.setHotel(mapHotelToDTO(booking.getHotel()));
			bookingDTO.setTotalAmount(booking.getTotalAmount());
			bookingDTO.setNoOfCustomers(booking.getNoOfCustomers());
			bookingDTO.setNoOfDays(booking.getNoOfDays());

			bookingDTOs.add(bookingDTO);
		}
		return bookingDTOs;

	}

	public BookingDTO findByRoomId(Integer roomId) {
		Booking booking = bookingRepo.findByRoomId(roomId);
		BookingDTO bookingDTO = new BookingDTO();
		bookingDTO.setBookingId(booking.getBookingId());
		bookingDTO.setCheckIn(booking.getCheckIn());
		bookingDTO.setCheckOut(booking.getCheckOut());
		bookingDTO.setCustomer(MapCustomerToDTO(booking.getCustomerList()));
		bookingDTO.setRoom(MapRoomToDTO(booking.getRoom()));
		bookingDTO.setHotel(mapHotelToDTO(booking.getHotel()));
		bookingDTO.setTotalAmount(booking.getTotalAmount());
		bookingDTO.setNoOfCustomers(booking.getNoOfCustomers());
		bookingDTO.setNoOfDays(booking.getNoOfDays());

		return bookingDTO;
	}

	private HotelDTO mapHotelToDTO(Hotel hotel) {
		// TODO Auto-generated method stub

		HotelDTO hotelDTO = modelMapper.map(hotel, HotelDTO.class);
		return hotelDTO;
	}

	private RoomDTO MapRoomToDTO(Room room) {
		RoomDTO roomDTO = new RoomDTO();
		roomDTO = modelMapper.map(room, RoomDTO.class);
		return roomDTO;
	}

	private List<CustomerDTO> MapCustomerToDTO(List<Customer> customerList) {
		// TODO Auto-generated method stub

		List<CustomerDTO> customerDTOs = customerList.stream().map(source -> modelMapper.map(source, CustomerDTO.class))
				.collect(Collectors.toList());
		return customerDTOs;
	}
}
