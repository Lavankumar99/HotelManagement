package com.hotelbookingapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hotelbookingapp.dto.HotelDTO;
import com.hotelbookingapp.service.IHotelService;

@RestController
@RequestMapping("/hotel")
public class HotelController {

	@Autowired
	IHotelService hotelService;

	@PostMapping("/addHotel")
	public HotelDTO addHotel(@RequestBody HotelDTO hotelDTO) {
		return hotelService.addHotel(hotelDTO);
	}

	@GetMapping("/findByHotelId/{hotel_id}")
	public HotelDTO findByHotelId(@PathVariable(value = "hotel_id") Integer hotel_id) {
		return hotelService.findByHotelId(hotel_id);
	}

	@GetMapping("/findByHotelName/{hotel_name}")
	public HotelDTO findByHotelId(@PathVariable(value = "hotel_name") String hotel_name) {
		return hotelService.findByHotelName(hotel_name);
	}

	@GetMapping("/findByHotelCity/{hotel_city}")
	public List<HotelDTO> findByHotelCity(@PathVariable(value = "hotel_city") String hotel_city) {
		return hotelService.findByCity(hotel_city);
	}

	@GetMapping("/findall")
	public List<HotelDTO> findAllHotels() {
		return hotelService.findAllHotels();
	}

	@PutMapping("/update/{hotel_id}")
	public String updateHotel(@PathVariable(value = "hotel_id") Integer hotel_id, @RequestBody HotelDTO hotelDTO) {
		return hotelService.updateHotel(hotel_id, hotelDTO);
	}
}
