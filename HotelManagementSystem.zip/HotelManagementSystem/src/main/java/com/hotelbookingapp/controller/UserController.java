package com.hotelbookingapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hotelbookingapp.dto.UserDTO;
import com.hotelbookingapp.service.IUserService;

@RestController
@RequestMapping("/user")
public class UserController {
	@Autowired
	private IUserService userService;

	@PostMapping("/registerUser")
	public UserDTO addUser(@RequestBody UserDTO userDTO) {
		return userService.registerUser(userDTO);
	}

	@PostMapping("/login/{username}/{password}")
	public String userLogin(@PathVariable(value = "username") String username,
			@PathVariable(value = "password") String password) {
		return userService.signIn(username, password);
	}

	@PostMapping("/logout/{username}/{password}")
	public String userLogout(@PathVariable(value = "username") String username,
			@PathVariable(value = "password") String password) {
		return userService.signOut(username, password);
	}

}
