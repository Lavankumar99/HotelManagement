package com.hotelbookingapp.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hotelbookingapp.entity.Booking;

@Repository
public interface IBookingRepo extends JpaRepository<Booking, Integer> {

	@Modifying
	@Transactional
	@Query(value = "delete from booked_customer_tbl where booking_id = ?1 ", nativeQuery = true)
	public void deleteBookedCustomers(Integer booking_id);

	@Modifying
	@Transactional
	@Query(value = "delete from booking_tbl where booking_id = ?1 ", nativeQuery = true)
	public void cancelBooking(Integer booking_id);

	@Query(value = "select * from booking_tbl where user_user_id=?1", nativeQuery = true)
	public List<Booking> findByUserId(Integer userId);

	@Query(value = "select * from booking_tbl where hotel_hotel_id=?1", nativeQuery = true)
	public List<Booking> findByHotelId(Integer hotelId);

	@Query(value = "select * from booking_tbl where room_room_id=?1", nativeQuery = true)
	public Booking findByRoomId(Integer roomId);
}
