package com.hotelbookingapp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hotelbookingapp.entity.Room;

@Repository
public interface IRoomRepo extends JpaRepository<Room, Integer> {

	@Query(value = "select * from room_tbl where hotel_hotel_id=?1", nativeQuery = true)
	public List<Room> findRoomsByHotelId(Integer hotelId);

	@Query(value = "select * from room_tbl where hotel_hotel_id=?1 and status=?2", nativeQuery = true)
	public List<Room> findRoomsByHotelIdAndStatus(Integer hotelId, String status);

	;

}
