package com.hotelbookingapp.entity;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.Data;

@Data
@Entity
@Table(name = "booking_tbl")
public class Booking {

	// @Override

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer bookingId;

	@ManyToMany
	@JoinTable(name = "booked_customer_tbl", joinColumns = @JoinColumn(name = "booking_id"), inverseJoinColumns = @JoinColumn(name = "customer_id"))
	private List<Customer> customerList = new ArrayList<>();

	@OneToOne

	private Hotel hotel;

	@NotNull
	@Column(nullable = false)
	private LocalDate checkIn;
	@NotNull
	@Column(nullable = false)
	private LocalDate checkOut;
	@NotNull
	@Column(nullable = false)
	private Integer noOfCustomers;
	@NotNull
	@Column(nullable = false)
	private Long noOfDays;
	@NotNull
	@Column(nullable = false)
	private Double totalAmount;

	@ManyToOne
	private User user;

	@OneToOne
	private Room room;

}
