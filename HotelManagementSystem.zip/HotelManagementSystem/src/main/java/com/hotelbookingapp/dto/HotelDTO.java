package com.hotelbookingapp.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class HotelDTO {
	private Integer hotelId;
	private String hotelName;
	private String hotelCity;
	private String description;
	private String hotelEmail;
	private Long hotelContactNo;

	public HotelDTO(Integer hotelId, String hotelName, String hotelCity) {
		super();
		this.hotelId = hotelId;
		this.hotelName = hotelName;
		this.hotelCity = hotelCity;
	}

}
