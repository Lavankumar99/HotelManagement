package com.hotelbookingapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hotelbookingapp.dto.RoomDTO;
import com.hotelbookingapp.service.IRoomService;
import com.hotelbookingapp.util.RoomStatus;

@RestController
@RequestMapping("/room")
public class RoomController {

	@Autowired
	private IRoomService roomService;

	@PostMapping("/addRoom/{hotel_id}")
	public String addRoom(@PathVariable(value = "hotel_id") Integer hotel_id, @RequestBody RoomDTO roomDTO) {
		return roomService.addRoom(hotel_id, roomDTO);
	}

	@GetMapping("/findById/{room_id}")
	public RoomDTO findById(@PathVariable(value = "room_id") Integer room_id) {
		return roomService.findByRoomId(room_id);
	}

	@GetMapping("/findByHotelId/{hotel_id}")
	public List<RoomDTO> findByHotelId(@PathVariable(value = "hotel_id") Integer hotel_id) {
		return roomService.findByHotelId(hotel_id);
	}

	@GetMapping("/findByHotelName/{hotel_name}")
	public List<RoomDTO> findByHotelId(@PathVariable(value = "hotel_name") String hotel_name) {
		return roomService.findByHotelName(hotel_name);
	}

	@GetMapping("/findByHotelIdAndStatus/{hotel_id}/{status}")
	public List<RoomDTO> findByHotelId(@PathVariable(value = "hotel_id") Integer hotel_id,
			@PathVariable(value = "status") RoomStatus status) {
		return roomService.findRoomsByHotelAndStatus(hotel_id, status);
	}

	@GetMapping("/findallavailablerooms")
	public List<RoomDTO> findallavailablerooms() {
		return roomService.findAllAvailableRooms();
	}

	@GetMapping("/findallrooms")
	public List<RoomDTO> findallrooms() {
		return roomService.findAllRooms();
	}

	@PutMapping("/update/{room_id}")
	public String updateRoom(@PathVariable(value = "room_id") Integer room_id, @RequestBody RoomDTO roomDTO) {
		return roomService.updateRoom(room_id, roomDTO);
	}

}
