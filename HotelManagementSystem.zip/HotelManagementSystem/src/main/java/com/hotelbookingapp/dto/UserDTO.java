package com.hotelbookingapp.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class UserDTO {

	private Integer userId;

	private String userName;

	private String password;

	private Long mobileNumber;

	private String userEmail;

	public UserDTO(Integer userId, String userName, String password, Long mobileNumber, String userEmail) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.password = password;
		this.mobileNumber = mobileNumber;
		this.userEmail = userEmail;
	}

}
