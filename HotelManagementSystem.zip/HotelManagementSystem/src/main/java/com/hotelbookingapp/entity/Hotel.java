package com.hotelbookingapp.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
@Entity
@Table(name = "hotel_tbl")
public class Hotel {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer hotelId;
	@NotNull
	@NotBlank
	@Column(nullable = false)
	private String hotelName;
	@NotNull
	@NotBlank
	@Column(nullable = false)
	private String hotelCity;
	@NotNull
	@NotBlank
	@Column(nullable = false)
	private String description;
	@NotNull
	@NotBlank
	@Column(nullable = false)
	private String hotelEmail;
	@NotNull
	@Column(nullable = false)
	private Long hotelContactNo;

	@OneToMany(mappedBy = "hotel", cascade = CascadeType.ALL)
	private List<Room> listOfRooms = new ArrayList<>();

	public Hotel(Integer hotelId, @NotNull @NotBlank String hotelName, @NotNull @NotBlank String hotelCity) {
		super();
		this.hotelId = hotelId;
		this.hotelName = hotelName;
		this.hotelCity = hotelCity;
	}

}
