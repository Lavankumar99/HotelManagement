package com.hotelbookingapp.dto;

import com.hotelbookingapp.util.RoomStatus;
import com.hotelbookingapp.util.RoomType;

import lombok.Data;

@Data
public class RoomDTO {

	private Integer roomId;

	private Integer roomNo;

	private RoomType roomType;

	private Integer roomCapacity;

	private Double ratePerDay;

	private RoomStatus status;

}
