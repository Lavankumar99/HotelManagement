package com.hotelbookingapp.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;

import com.hotelbookingapp.dto.HotelDTO;
import com.hotelbookingapp.dto.UserDTO;
import com.hotelbookingapp.entity.Hotel;
import com.hotelbookingapp.entity.User;
import com.hotelbookingapp.repository.IHotelRepo;
import com.hotelbookingapp.repository.IUserRepo;
import com.hotelbookingapp.service.HotelServiceImpl;
import com.hotelbookingapp.service.UserServiceImpl;

@RunWith(MockitoJUnitRunner.class)
@SpringBootTest
class HotelManagementSystemApplicationTests {

	@InjectMocks
	UserServiceImpl userServiceImpl;
	@InjectMocks
	HotelServiceImpl hotelServiceImpl;

	@Mock
	IUserRepo userRepository;
	@Mock
	IHotelRepo hotelRepository;

	@Test
	public void addUserTest() {
		User user = new User(3, "abc", "123", 1222221123L, "wwr@email");
		UserDTO userDTO = new UserDTO(3, "abc", "123", 1222221123L, "wwr@email");
		when(userRepository.save(user)).thenReturn(user);
		UserDTO userDTOch = userServiceImpl.registerUser(userDTO);
		assertEquals(userDTOch.getUserName(), user.getUserName());
		assertEquals(userDTOch.getUserEmail(), user.getUserEmail());
		assertEquals(userDTOch.getUserId(), user.getUserId());

	}

	@Test
	public void addHotelTest() {
		Hotel hotel = new Hotel(3, "abc", "123");
		HotelDTO hotelDTO = new HotelDTO(3, "abc", "123");
		HotelDTO hotelDTOch = hotelServiceImpl.addHotel(hotelDTO);
		assertEquals(hotelDTOch.getHotelId(), hotel.getHotelId());
		assertEquals(hotelDTOch.getHotelCity(), hotel.getHotelCity());
		assertEquals(hotelDTOch.getHotelName(), hotel.getHotelName());

	}

}
