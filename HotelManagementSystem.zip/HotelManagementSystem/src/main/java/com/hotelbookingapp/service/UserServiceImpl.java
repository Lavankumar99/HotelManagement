package com.hotelbookingapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hotelbookingapp.dto.UserDTO;
import com.hotelbookingapp.entity.User;
import com.hotelbookingapp.repository.IUserRepo;

@Service
public class UserServiceImpl implements IUserService {

	@Autowired
	private IUserRepo userRepo;

	@Override
	public UserDTO registerUser(UserDTO userDTO) {

		User user = new User();

		user.setUserName(userDTO.getUserName());
		user.setUserEmail(userDTO.getUserEmail());
		user.setPassword(userDTO.getPassword());
		user.setMobileNumber(userDTO.getMobileNumber());
		userRepo.save(user);

		return userDTO;

	}

	public String signIn(String username, String password) {
		User user = userRepo.findByUserNameAndPassword(username, password);

		if (user != null) {
			return "Login Successfull";
		} else
			return "Sorry! Please check username and password";
	}

	public String signOut(String username, String password) {
		User user = userRepo.findByUserNameAndPassword(username, password);

		if (user != null) {
			return "LogOut Successfull";
		} else
			return "Sorry! Please check username and password";
	}

}
