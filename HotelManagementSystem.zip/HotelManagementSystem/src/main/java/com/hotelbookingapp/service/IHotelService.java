package com.hotelbookingapp.service;

import java.util.List;

import com.hotelbookingapp.dto.HotelDTO;

public interface IHotelService {
	public HotelDTO addHotel(HotelDTO hotel);

	public String updateHotel(Integer hotelId, HotelDTO hotel);

	public List<HotelDTO> findAllHotels();

	public HotelDTO findByHotelId(Integer hotelId);

	public List<HotelDTO> findByCity(String city);

	public HotelDTO findByHotelName(String hotelName);

}
