package com.hotelbookingapp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hotelbookingapp.entity.Customer;

@Repository
public interface ICustomerRepo extends JpaRepository<Customer, Integer> {
	@Query(value = "select * from customer_tbl where user_user_id=?1", nativeQuery = true)
	public List<Customer> findByuserId(Integer userId);

	public Customer findByCustomerNo(Long cNumber);

	public List<Customer> findByCustomerAge(Integer custAge);
}
