package com.hotelbookingapp.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.hotelbookingapp.util.RoomStatus;
import com.hotelbookingapp.util.RoomType;

import lombok.Data;

@Data
@Entity
@Table(name = "room_tbl")
public class Room {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer roomId;

	@ManyToOne
	private Hotel hotel;

	@NotNull
	@Column(nullable = false)
	private Integer roomNo;
	@NotNull
	@Column(nullable = false)
	private RoomType roomType;
	@NotNull
	@Column(nullable = false)
	private Integer roomCapacity;
	@NotNull
	@Column(nullable = false)
	private Double ratePerDay;

	@NotNull
	@Column(nullable = false)
	private RoomStatus status;
}
