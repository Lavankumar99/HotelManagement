package com.hotelbookingapp.util;

public enum RoomType {
	SINGLE, DOUBLE, SUITE;

}