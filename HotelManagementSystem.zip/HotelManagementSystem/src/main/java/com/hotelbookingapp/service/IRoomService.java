package com.hotelbookingapp.service;

import java.util.List;

import com.hotelbookingapp.dto.RoomDTO;
import com.hotelbookingapp.util.RoomStatus;

public interface IRoomService {
	public String addRoom(Integer hotelId, RoomDTO roomDetails);

	public String updateRoom(Integer room_id, RoomDTO roomDetails);

	public RoomDTO findByRoomId(Integer roomDetailsId);

	public List<RoomDTO> findByHotelId(Integer hotelId);

	public List<RoomDTO> findByHotelName(String hotelName);

	public List<RoomDTO> findRoomsByHotelAndStatus(Integer hotelId, RoomStatus status);

	public List<RoomDTO> findAllAvailableRooms();

	public List<RoomDTO> findAllRooms();
}
