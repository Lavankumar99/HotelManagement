package com.hotelbookingapp.service;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hotelbookingapp.dto.HotelDTO;
import com.hotelbookingapp.entity.Hotel;
import com.hotelbookingapp.exception.HotelNotFoundException;
import com.hotelbookingapp.repository.IHotelRepo;

@Service
public class HotelServiceImpl implements IHotelService {

	@Autowired
	IHotelRepo hotelRepo;

	@Autowired
	private ModelMapper modelMapper;

	public HotelDTO addHotel(HotelDTO hotelDTO) {
		Hotel hotel = new Hotel();

		hotel.setHotelName(hotelDTO.getHotelName());
		hotel.setHotelId(hotelDTO.getHotelId());
		hotel.setHotelCity(hotelDTO.getHotelCity());
		hotel.setHotelContactNo(hotelDTO.getHotelContactNo());
		hotel.setDescription(hotelDTO.getDescription());
		hotel.setHotelEmail(hotelDTO.getHotelEmail());

		hotelRepo.save(hotel);
		return hotelDTO;
	}

	public List<HotelDTO> findAllHotels() {
		List<Hotel> hotels = hotelRepo.findAll();

		List<HotelDTO> hotelDTOs = hotels.stream().map(source -> modelMapper.map(source, HotelDTO.class))
				.collect(Collectors.toList());
		return hotelDTOs;

	}

	public HotelDTO findByHotelId(Integer hotelId) {
		Hotel hotel = hotelRepo.findById(hotelId).get();
		HotelDTO hotelDTO = modelMapper.map(hotel, HotelDTO.class);

		return hotelDTO;
	}

	public List<HotelDTO> findByCity(String city) {
		List<Hotel> hotels = hotelRepo.findByHotelCity(city);

		List<HotelDTO> hotelDTOs = hotels.stream().map(source -> modelMapper.map(source, HotelDTO.class))
				.collect(Collectors.toList());

		return hotelDTOs;
	}

	public HotelDTO findByHotelName(String hotelName) {

		Hotel hotel = hotelRepo.findByHotelName(hotelName);
		HotelDTO hotelDTO = modelMapper.map(hotel, HotelDTO.class);

		return hotelDTO;

	}

	public String updateHotel(Integer hotel_id, HotelDTO hotelDTO) {
		try {
			Hotel hotel = hotelRepo.findById(hotel_id).orElseThrow(() -> new HotelNotFoundException());

			if (hotelDTO.getHotelName() != null)
				hotel.setHotelName(hotelDTO.getHotelName());
			if (hotelDTO.getDescription() != null)
				hotel.setDescription(hotelDTO.getDescription());
			if (hotelDTO.getHotelCity() != null)
				hotel.setHotelCity(hotelDTO.getHotelCity());
			if (hotelDTO.getHotelEmail() != null)
				hotel.setHotelEmail(hotelDTO.getHotelEmail());
			if (hotelDTO.getHotelContactNo() != 0)
				hotel.setHotelContactNo(hotelDTO.getHotelContactNo());
			hotelRepo.save(hotel);
		} catch (HotelNotFoundException e) {
			System.out.println(e);
			return "Hotel data not updated";

		}
		return "Hotel Updated Successfully";
	}

}
