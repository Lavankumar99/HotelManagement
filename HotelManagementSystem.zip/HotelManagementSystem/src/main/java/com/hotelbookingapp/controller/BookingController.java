package com.hotelbookingapp.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hotelbookingapp.dto.BookingDTO;
import com.hotelbookingapp.service.IBookingService;

@RestController
@RequestMapping("/book")
public class BookingController {

	@Autowired
	private IBookingService bookingService;

	@PostMapping("/booking/{checkIn}/{checkOut}/{user_id}/{room_id}")
	public String addBookingDetails(
			@PathVariable(value = "checkIn") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate checkIn,
			@PathVariable(value = "checkOut") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate checkOut,
			@PathVariable(value = "user_id") Integer user_id, @PathVariable(value = "room_id") Integer room_id) {
		return bookingService.addBookingDetails(checkIn, checkOut, user_id, room_id);
	}

	@GetMapping("/findByBookingId/{booking_id}")
	public BookingDTO findByBookingId(@PathVariable(value = "booking_id") Integer booking_id) {
		return bookingService.findByBookingId(booking_id);
	}

	@GetMapping("/findByRoomId/{room_id}")
	public BookingDTO findByRoomId(@PathVariable(value = "room_id") Integer room_id) {
		return bookingService.findByRoomId(room_id);
	}

	@GetMapping("/findByUserId/{user_id}")
	public List<BookingDTO> findByUserId(@PathVariable(value = "user_id") Integer user_id) {
		return bookingService.findByUserId(user_id);
	}

	@GetMapping("/findByHotelId/{hotel_id}")
	public List<BookingDTO> findByHotelId(@PathVariable(value = "hotel_id") Integer hotel_id) {
		return bookingService.findByHotelId(hotel_id);
	}

	@GetMapping("/findall")
	public List<BookingDTO> findAllBookings() {
		return bookingService.findAllBookings();
	}
}
