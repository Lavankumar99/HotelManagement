package com.hotelbookingapp.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hotelbookingapp.dto.RoomDTO;
import com.hotelbookingapp.entity.Hotel;
import com.hotelbookingapp.entity.Room;
import com.hotelbookingapp.exception.HotelNotFoundException;
import com.hotelbookingapp.exception.RoomNotFoundException;
import com.hotelbookingapp.repository.IHotelRepo;
import com.hotelbookingapp.repository.IRoomRepo;
import com.hotelbookingapp.util.RoomStatus;

@Service
public class RoomServiceimpl implements IRoomService {

	@Autowired
	IHotelRepo hotelRepo;
	@Autowired
	IRoomRepo roomDetailsRepo;
	@Autowired
	private ModelMapper modelMapper;

	public String addRoom(Integer hotelId, RoomDTO roomDetailsDTO) {
		try {
			Hotel hotel = hotelRepo.findById(hotelId).orElseThrow(() -> new HotelNotFoundException());
			Room room = new Room();
			room.setRoomCapacity(roomDetailsDTO.getRoomCapacity());
			room.setRatePerDay(roomDetailsDTO.getRatePerDay());
			room.setRoomId(roomDetailsDTO.getRoomId());
			room.setRoomNo(roomDetailsDTO.getRoomNo());
			room.setRoomType(roomDetailsDTO.getRoomType());
			room.setStatus(roomDetailsDTO.getStatus());
			room.setHotel(hotel);
			roomDetailsRepo.save(room);
			return "Room Added Successfully";

		} catch (HotelNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("Hotel Not Found" + e);
			return "Hotel Not Found";

		}
	}

	public RoomDTO findByRoomId(Integer roomId) {
		Room room = roomDetailsRepo.findById(roomId).get();
		RoomDTO roomDTO = modelMapper.map(room, RoomDTO.class);
		return roomDTO;
	}

	public List<RoomDTO> findByHotelId(Integer hotelId) {
		List<Room> rooms = roomDetailsRepo.findRoomsByHotelId(hotelId);

		List<RoomDTO> roomDTOs = new ArrayList<RoomDTO>();

		roomDTOs = rooms.stream().map(source -> modelMapper.map(source, RoomDTO.class)).collect(Collectors.toList());

		return roomDTOs;
	}

	public List<RoomDTO> findByHotelName(String hotelName) {
		Hotel hotel = hotelRepo.findByHotelName(hotelName);
		List<Room> rooms = roomDetailsRepo.findRoomsByHotelId(hotel.getHotelId());

		List<RoomDTO> roomDTOs = new ArrayList<RoomDTO>();

		roomDTOs = rooms.stream().map(source -> modelMapper.map(source, RoomDTO.class)).collect(Collectors.toList());

		return roomDTOs;
	}

	public List<RoomDTO> findRoomsByHotelAndStatus(Integer hotelId, RoomStatus status) {
		List<Room> rooms = roomDetailsRepo.findRoomsByHotelId(hotelId);
		List<RoomDTO> roomDTOs = new ArrayList<RoomDTO>();

		for (Room room : rooms) {
			if (room.getStatus() == status) {
				RoomDTO roomDTO = modelMapper.map(room, RoomDTO.class);
				roomDTOs.add(roomDTO);
			}
		}
		return roomDTOs;

	}

	public String updateRoom(Integer room_id, RoomDTO roomDetails) {
		try {
			Room room = roomDetailsRepo.findById(room_id).orElseThrow(() -> new RoomNotFoundException());

			if (roomDetails.getRoomNo() != 0)
				room.setRoomNo(roomDetails.getRoomNo());
			if (roomDetails.getRatePerDay() != 0)
				room.setRatePerDay(roomDetails.getRatePerDay());
			if (roomDetails.getRoomType() != null)
				room.setRoomType(roomDetails.getRoomType());
			if (roomDetails.getStatus() != null)
				room.setStatus(roomDetails.getStatus());
			if (roomDetails.getRoomCapacity() != 0)
				room.setRoomCapacity(roomDetails.getRoomCapacity());

			roomDetailsRepo.save(room);
		} catch (RoomNotFoundException e) {
			System.out.println(e);
			return "Room data not updated";

		}
		return "Room Updated Successfully";
	}

	@Override
	public List<RoomDTO> findAllAvailableRooms() {

		List<Room> rooms = roomDetailsRepo.findAll();
		List<RoomDTO> roomDTOs = new ArrayList<RoomDTO>();

		for (Room room : rooms) {

			if (room.getStatus() == RoomStatus.AVAILABLE) {
				RoomDTO roomDTO = new RoomDTO();
				roomDTO = modelMapper.map(room, RoomDTO.class);
				roomDTOs.add(roomDTO);
			}
		}
		return roomDTOs;
	}

	public List<RoomDTO> findAllRooms() {

		List<Room> rooms = roomDetailsRepo.findAll();
		List<RoomDTO> roomDTOs = rooms.stream().map(source -> modelMapper.map(source, RoomDTO.class))
				.collect(Collectors.toList());

		return roomDTOs;
	}

}