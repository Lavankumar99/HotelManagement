package com.hotelbookingapp.dto;

import lombok.Data;

@Data
public class CustomerDTO {

	private Integer customerId;

	private String customerName;

	private Integer customerAge;

	private Long customerNo;

}
