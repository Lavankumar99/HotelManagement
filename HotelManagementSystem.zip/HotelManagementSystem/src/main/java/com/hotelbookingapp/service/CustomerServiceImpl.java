package com.hotelbookingapp.service;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hotelbookingapp.dto.CustomerDTO;
import com.hotelbookingapp.entity.Customer;
import com.hotelbookingapp.entity.User;
import com.hotelbookingapp.exception.CustomerNotFoundException;
import com.hotelbookingapp.exception.UserNotFoundException;
import com.hotelbookingapp.repository.ICustomerRepo;
import com.hotelbookingapp.repository.IUserRepo;

@Service
public class CustomerServiceImpl implements ICustomerService {

	@Autowired
	private IUserRepo userRepo;
	@Autowired
	private ICustomerRepo customerRepo;
	@Autowired
	private ModelMapper modelMapper;

	public CustomerDTO addCustomer(Integer userId, CustomerDTO customerDTO) {
		try {
			Customer customer = new Customer();

			User user = userRepo.findById(userId).orElseThrow(() -> new UserNotFoundException());

			customer.setCustomerId(customerDTO.getCustomerId());
			customer.setCustomerAge(customerDTO.getCustomerAge());
			customer.setCustomerName(customerDTO.getCustomerName());
			customer.setCustomerNo(customerDTO.getCustomerNo());
			customer.setUser(user);

			customerRepo.save(customer);

			return customerDTO;
		} catch (UserNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("User Not Found" + e);
			return null;

		}

	}

	public List<CustomerDTO> viewAllCustomer() {
		List<Customer> customers = customerRepo.findAll();
		List<CustomerDTO> customerDTOs = customers.stream().map(source -> modelMapper.map(source, CustomerDTO.class))
				.collect(Collectors.toList());
		return customerDTOs;
	}

	public CustomerDTO findByContactNo(Long contactNo) {
		Customer customer = customerRepo.findByCustomerNo(contactNo);
		CustomerDTO customerDTO = modelMapper.map(customer, CustomerDTO.class);

		return customerDTO;
	}

	public List<CustomerDTO> findByAge(Integer custAge) {
		List<Customer> customers = customerRepo.findByCustomerAge(custAge);
		List<CustomerDTO> customerDTOs = customers.stream().map(source -> modelMapper.map(source, CustomerDTO.class))
				.collect(Collectors.toList());
		return customerDTOs;
	}

	public String updateCustomer(Integer custId, CustomerDTO customerDTO) {
		try {
			Customer customer = customerRepo.findById(custId).orElseThrow(() -> new CustomerNotFoundException());

			if (customerDTO.getCustomerAge() != 0)
				customer.setCustomerAge(customerDTO.getCustomerAge());
			if (customerDTO.getCustomerName() != null)
				customer.setCustomerName(customerDTO.getCustomerName());
			if (customerDTO.getCustomerNo() != 0)
				customer.setCustomerNo(customerDTO.getCustomerNo());

			customerRepo.save(customer);

		} catch (CustomerNotFoundException e) {
			System.out.println(e);
			return "Customer data not updated";

		}
		return "Customer Updated Successfully";
	}

}
