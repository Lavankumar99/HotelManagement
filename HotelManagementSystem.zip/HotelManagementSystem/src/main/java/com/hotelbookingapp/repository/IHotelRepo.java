package com.hotelbookingapp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hotelbookingapp.entity.Hotel;

@Repository
public interface IHotelRepo extends JpaRepository<Hotel, Integer> {

	public Hotel findByHotelName(String hotelName);

	public List<Hotel> findByHotelCity(String cityName);
}
