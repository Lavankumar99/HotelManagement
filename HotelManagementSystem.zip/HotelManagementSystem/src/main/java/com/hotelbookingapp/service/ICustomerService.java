package com.hotelbookingapp.service;

import java.util.List;

import com.hotelbookingapp.dto.CustomerDTO;

public interface ICustomerService {

	public CustomerDTO addCustomer(Integer userId, CustomerDTO customer);

	public String updateCustomer(Integer custId, CustomerDTO customer);

	public List<CustomerDTO> viewAllCustomer();

	public CustomerDTO findByContactNo(Long contactNo);

	public List<CustomerDTO> findByAge(Integer custAge);
}
