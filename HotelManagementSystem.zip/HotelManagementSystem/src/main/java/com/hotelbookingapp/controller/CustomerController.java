package com.hotelbookingapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hotelbookingapp.dto.CustomerDTO;
import com.hotelbookingapp.service.ICustomerService;

@RestController
@RequestMapping("/customer")
public class CustomerController {
	@Autowired
	private ICustomerService customerService;

	@PostMapping("/addCustomer/{user_id}")
	public CustomerDTO addCustomer(@PathVariable(value = "user_id") Integer user_id,
			@RequestBody CustomerDTO customerDTO) {
		return customerService.addCustomer(user_id, customerDTO);
	}

	@GetMapping("/findByContactNo/{ContactNo}")
	public CustomerDTO findByHotelId(@PathVariable(value = "ContactNo") Long ContactNo) {
		return customerService.findByContactNo(ContactNo);
	}

	@GetMapping("/findByAge/{Age}")
	public List<CustomerDTO> findByHotelId(@PathVariable(value = "Age") Integer Age) {
		return customerService.findByAge(Age);
	}

	@PutMapping("/update/{cust_id}")
	public String updateCustomer(@PathVariable(value = "cust_id") Integer cust_id,
			@RequestBody CustomerDTO customerDTO) {
		return customerService.updateCustomer(cust_id, customerDTO);
	}

	@GetMapping("/findall")
	public List<CustomerDTO> findAllCustomers() {
		return customerService.viewAllCustomer();
	}
}
