package com.hotelbookingapp.service;

import com.hotelbookingapp.dto.UserDTO;

public interface IUserService {
	public UserDTO registerUser(UserDTO user);

	public String signIn(String userName, String password);

	public String signOut(String userName, String password);
}
