package com.hotelbookingapp.util;

public enum RoomStatus {
	BOOKED, AVAILABLE;

}
