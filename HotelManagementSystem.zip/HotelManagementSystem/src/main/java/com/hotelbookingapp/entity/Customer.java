package com.hotelbookingapp.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
@Entity
@Table(name = "customer_tbl")
public class Customer {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer customerId;
	@NotNull
	@NotBlank
	@Column(nullable = false)
	private String customerName;
	@NotNull
	@Column(nullable = false)
	private Integer customerAge;
	@NotNull
	@Column(nullable = false, unique = true)
	private Long customerNo;

	@ManyToOne
	private User user;

}
