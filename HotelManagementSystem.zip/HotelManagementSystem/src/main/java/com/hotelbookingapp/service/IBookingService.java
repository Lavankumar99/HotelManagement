package com.hotelbookingapp.service;

import java.time.LocalDate;
import java.util.List;

import com.hotelbookingapp.dto.BookingDTO;

public interface IBookingService {
	public String addBookingDetails(LocalDate checkIn, LocalDate checkOut, Integer userId, Integer roomId);

	public String cancelBooking(Integer bookingId);

	public List<BookingDTO> findAllBookings();

	public BookingDTO findByBookingId(Integer bookingId);

	public List<BookingDTO> findByUserId(Integer userId);

	public List<BookingDTO> findByHotelId(Integer hotelId);

	public BookingDTO findByRoomId(Integer roomId);

}
